/*
 Navicat Premium Data Transfer

 Source Server         : xampp数据库
 Source Server Type    : MySQL
 Source Server Version : 100408
 Source Host           : localhost:3306
 Source Schema         : gms

 Target Server Type    : MySQL
 Target Server Version : 100408
 File Encoding         : 65001

 Date: 22/03/2022 18:23:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course`  (
  `cid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `userid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`cid`) USING BTREE,
  INDEX `u_c`(`userid`) USING BTREE,
  CONSTRAINT `u_c` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES ('1', '数据库开发技术', '103');
INSERT INTO `course` VALUES ('2', 'java程序开发', '104');
INSERT INTO `course` VALUES ('3', 'web程序设计', '105');
INSERT INTO `course` VALUES ('4', 'web前端开发', '106');
INSERT INTO `course` VALUES ('5', 'Linux', '107');
INSERT INTO `course` VALUES ('6', 'C++开发技术', '108');


-- ----------------------------
-- Table structure for grade
-- ----------------------------
DROP TABLE IF EXISTS `grade`;
CREATE TABLE `grade`  (
  `gid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `instructor` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `money` decimal(10, 2) NULL DEFAULT NULL,
  PRIMARY KEY (`gid`) USING BTREE,
  INDEX `g_i`(`instructor`) USING BTREE,
  CONSTRAINT `g_i` FOREIGN KEY (`instructor`) REFERENCES `user` (`userid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of grade
-- ----------------------------
INSERT INTO `grade` VALUES ('1', '计科1班', '102', 123.57);
INSERT INTO `grade` VALUES ('2', '计科2班', '102', 100.24);
INSERT INTO `grade` VALUES ('3', '计科3班', '102', 0.00);
INSERT INTO `grade` VALUES ('4', '计科4班', '102', 0.00);

-- ----------------------------
-- Table structure for gspend
-- ----------------------------
DROP TABLE IF EXISTS `gspend`;
CREATE TABLE `gspend`  (
  `sgid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `gid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `balance` decimal(10, 2) NULL DEFAULT NULL,
  PRIMARY KEY (`sgid`) USING BTREE,
  INDEX `g_sg`(`gid`) USING BTREE,
  CONSTRAINT `g_sg` FOREIGN KEY (`gid`) REFERENCES `grade` (`gid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of gspend
-- ----------------------------
INSERT INTO `gspend` VALUES ('1', '1', '给班主任买个小汽车 消耗：￥98000元 结余：￥5620元', 5620.57);
INSERT INTO `gspend` VALUES ('4', '1', '给班主任买个小汽车 消耗：￥98000元 结余：￥5620元', 5620.57);
INSERT INTO `gspend` VALUES ('5', '3', '给班主任买个小汽车 消耗：￥98000元 结余：￥5620元', 5620.57);
INSERT INTO `gspend` VALUES ('78773070-1cd3-4f65-b010-da0e4e1c325b', '1', '支出 ￥10元 用于 给校长买小汽车 支出后结余：￥113.57元---操作人：张三a', 113.57);

-- ----------------------------
-- Table structure for gu
-- ----------------------------
DROP TABLE IF EXISTS `gu`;
CREATE TABLE `gu`  (
  `guid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `gid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `userid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`guid`) USING BTREE,
  INDEX `gu_u`(`userid`) USING BTREE,
  INDEX `gu_g`(`gid`) USING BTREE,
  CONSTRAINT `gu_g` FOREIGN KEY (`gid`) REFERENCES `grade` (`gid`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `gu_u` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;


-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `nid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `img` text CHARACTER SET utf8 COLLATE utf8_bin NULL,
  `sendtime` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`nid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;


-- ----------------------------
-- Table structure for uc
-- ----------------------------
DROP TABLE IF EXISTS `uc`;
CREATE TABLE `uc`  (
  `ucid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `userid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `cid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `score` double(10, 2) NULL DEFAULT NULL,
  PRIMARY KEY (`ucid`) USING BTREE,
  INDEX `c_uc`(`cid`) USING BTREE,
  INDEX `u_uc`(`userid`) USING BTREE,
  CONSTRAINT `c_uc` FOREIGN KEY (`cid`) REFERENCES `course` (`cid`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `u_uc` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;


-- ----------------------------
-- Table structure for workcheck
-- ----------------------------
DROP TABLE IF EXISTS `workcheck`;
CREATE TABLE `workcheck`  (
  `wcid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `userid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `cid` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `time` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`wcid`) USING BTREE,
  INDEX `u_wc`(`userid`) USING BTREE,
  INDEX `c_wc`(`cid`) USING BTREE,
  CONSTRAINT `c_wc` FOREIGN KEY (`cid`) REFERENCES `course` (`cid`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `u_wc` FOREIGN KEY (`userid`) REFERENCES `user` (`userid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;


SET FOREIGN_KEY_CHECKS = 1;
