<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>班级管理系统服务端</title>
</head>
<body>
<h1>班级管理系统服务端</h1><br>
<h2>服务端启动成功......</h2><br><br>
<h2>接口详情请看接口文档</h2>
<div>

</div>
</body>
</html>