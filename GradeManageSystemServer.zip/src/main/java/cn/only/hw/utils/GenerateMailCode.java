package cn.only.hw.utils;

import java.util.Random;

public class GenerateMailCode {
    //    s生成随机6位验证码
    private String code = "";

    public String getCode() {
        Random random = new Random();
        for (int i = 0; i < 6; i++) {
            int r = random.nextInt(10); //每次随机出一个数字（0-9）
            code = code + r;  //把每次随机出的数字拼在一起
        }
        return code;
    }


}
