//package cn.only.hw.utils;
//
//import cn.only.hw.constant.ResponsConstant;
//import org.apache.commons.lang.time.DateFormatUtils;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.core.io.ClassPathResource;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.mail.javamail.MimeMessageHelper;
//import org.springframework.stereotype.Controller;
//
//import javax.mail.MessagingException;
//import javax.mail.internet.MimeMessage;
//import java.io.*;
//import java.text.MessageFormat;
//import java.util.Date;
//
//@Controller
//public class SendEmail {
//    private ApplicationContext applicationContext;
//    //        qq邮箱  xfbnufmsgtqlfehe
//    @Autowired
//    private JavaMailSender javaMailSender;
//
//
//    private static final Logger LOGGER = LoggerFactory.getLogger(ClassLoader.class);
//
//    public int sendEmail(String from, String sendto, String emailname, String contentText) {
//        applicationContext = new ClassPathXmlApplicationContext("classpath:spring/applicationContext.xml");
//        javaMailSender = applicationContext.getBean(JavaMailSender.class);
//
//        MimeMessage mMessage = javaMailSender.createMimeMessage();//创建邮件对象
//        MimeMessageHelper mMessageHelper;
//
//        try {
//            // System.out.println(from);
//            mMessageHelper = new MimeMessageHelper(mMessage, true,"utf-8");
//            mMessageHelper.setFrom(from);//发件人邮箱
//            mMessageHelper.setTo(sendto);//收件人邮箱
//            mMessageHelper.setSubject(emailname);//邮件的主题
//
//            mMessageHelper.setText(buildContent(contentText), true);//邮件的文本内容，true表示文本以html格式打开
//            String alarmIconName = "template_mail/images/icon.png";
//            ClassPathResource img = new ClassPathResource(alarmIconName);
//            mMessageHelper.addInline("icon-alarm", img);
//            javaMailSender.send(mMessage);//发送邮件
//        } catch (MessagingException e) {
//            e.printStackTrace();
//            return ResponsConstant.SEND_EMAIL_ERROR_CODE;
//        }
//        return ResponsConstant.SEND_EMAIL_SUCCESS_CODE;
//    }
//
//
//    private static String buildContent(String contentText) {
//
//        //加载邮件html模板
//        String fileName = "template_mail/email_themp_sendemailcode.html";
//        String url = Thread.currentThread().getContextClassLoader().getResource(fileName).getFile();
////        InputStream inputStream = SendEmail.class.getClassLoader().getSystemResourceAsStream(fileName);
//        InputStream inputStream = null;
//        try {
//            inputStream = new FileInputStream(url);
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//        BufferedReader fileReader = new BufferedReader(new InputStreamReader(inputStream));
//        StringBuffer buffer = new StringBuffer();
//        String line = "";
//        try {
//            while ((line = fileReader.readLine()) != null) {
//                buffer.append(line);
//            }
//        } catch (Exception e) {
//            LOGGER.error("读取文件失败，fileName:{}", fileName, e);
//        } finally {
//            try {
//                inputStream.close();
//                fileReader.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//
//
//        //绿色
//        String emailHeadColor = "#10fa81";
//        String date = DateFormatUtils.format(new Date(), "yyyy/MM/dd HH:mm:ss");
//        //填充hhtml模板中的五个参数
////        String htmlText = MessageFormat.format(buffer.toString(), emailHeadColor, contentText, date, header, linesBuffer.toString());
//        String htmlText = MessageFormat.format(buffer.toString(), emailHeadColor, contentText, date, "请您牢记验证码邮箱 以后找回密码使用");
//
//        //改变表格样式
////        htmlText = htmlText.replaceAll("<td>", "<td style=\"padding:6px 10px; line-height: 150%;\">");
////        htmlText = htmlText.replaceAll("<tr>", "<tr style=\"border-bottom: 1px solid #eee; color:#666;\">");
//        return htmlText;
//    }
//}
