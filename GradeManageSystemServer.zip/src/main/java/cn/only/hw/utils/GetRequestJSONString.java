package cn.only.hw.utils;

import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JSONString;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class GetRequestJSONString {
    /**
     * 返回jsonObj参数
     * @param request
     * @return
     */
    public static JSONObject getRequestParamsObj(HttpServletRequest request) {
        JSONObject paramsObj = new JSONObject();
        try {
            BufferedReader streamReader = new BufferedReader( new InputStreamReader(request.getInputStream()));
            StringBuilder responseStrBuilder = new StringBuilder();
            String inputStr;
            while ((inputStr = streamReader.readLine()) != null)
                responseStrBuilder.append(inputStr);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("data",responseStrBuilder.toString());

            paramsObj = jsonObject.getJSONObject("data");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return paramsObj;
    }
}
