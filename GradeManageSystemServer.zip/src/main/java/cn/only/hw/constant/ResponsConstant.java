package cn.only.hw.constant;

public class ResponsConstant {
    //    成功类
    public static final String REQUEST_SUCCESS_MSG = "success";
    public static final int REQUEST_SUCCESS_CODE = 200;

    //    操作失败
    public static final String REQUEST_FAIL_MSG = "error";
    public static final int REQUEST_FAIL_CODE = 201;


    // 服务器参数
    public static final String hmethod = "http";
    public static final String host = "192.168.2.5";
    public static final String port = "8080";
    public static final String project = "HomeBillsServer";
    public static final String url = String.format("%s://%s:%s/%s/",hmethod,host,port,project);



}
