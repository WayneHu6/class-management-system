package cn.only.hw.entity;

import cn.only.hw.constant.ResponsConstant;

import java.util.HashMap;
import java.util.Map;

/**
 * 通用的返回的类
 *
 */
public class Result {
    //状态码   200-成功    100-失败
    private int code;
    //提示信息
    private String msg;

    // 服务器返回的数据
    private Map<String, Object> data = new HashMap<String, Object>();

    @Override
    public String toString() {
        return "Result{" +
                "code=" + code +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }

    public Result success() {
        Result result = new Result();
        result.setCode(ResponsConstant.REQUEST_SUCCESS_CODE);
        result.setMsg(ResponsConstant.REQUEST_SUCCESS_MSG);
        return result;
    }

    public Result fail() {
        Result result = new Result();
        result.setCode(ResponsConstant.REQUEST_FAIL_CODE);
        result.setMsg(ResponsConstant.REQUEST_FAIL_MSG);
        return result;
    }

    public Result add(String key, Object value) {
        this.getData().put(key, value);
        return this;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }

}