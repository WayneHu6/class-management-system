package cn.only.hw.entity;

public class Workcheck {
    private String wcid;

    private String userid;

    private String cid;

    private String state;

    private String time;

    public String getWcid() {
        return wcid;
    }

    public void setWcid(String wcid) {
        this.wcid = wcid;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}