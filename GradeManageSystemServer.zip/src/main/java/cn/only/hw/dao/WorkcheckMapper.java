package cn.only.hw.dao;

import cn.only.hw.entity.Workcheck;

import java.util.List;

public interface WorkcheckMapper {
    int deleteByPrimaryKey(String wcid);

    int insert(Workcheck record);

    int insertSelective(Workcheck record);

    Workcheck selectByPrimaryKey(String wcid);

    int updateByPrimaryKeySelective(Workcheck record);

    int updateByPrimaryKey(Workcheck record);

    List<Workcheck> selectByUserid(String userid);

    List<Workcheck> selectAll();
}