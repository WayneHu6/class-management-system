package cn.only.hw.dao;

import cn.only.hw.entity.Gspend;

import java.util.List;

public interface GspendMapper {
    int deleteByPrimaryKey(String sgid);

    int insert(Gspend record);

    int insertSelective(Gspend record);

    Gspend selectByPrimaryKey(String sgid);

    int updateByPrimaryKeySelective(Gspend record);

    int updateByPrimaryKeyWithBLOBs(Gspend record);

    int updateByPrimaryKey(Gspend record);

    List<Gspend> selectByGid(String gid);
}