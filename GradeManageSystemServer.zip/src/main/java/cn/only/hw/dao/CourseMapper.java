package cn.only.hw.dao;

import cn.only.hw.entity.Course;

import java.util.List;

public interface CourseMapper {
    int deleteByPrimaryKey(String cid);

    int insert(Course record);

    int insertSelective(Course record);

    Course selectByPrimaryKey(String cid);

    int updateByPrimaryKeySelective(Course record);

    int updateByPrimaryKey(Course record);

    List<Course> selectAll();

    List<Course> selectByUserid(String userid);
}