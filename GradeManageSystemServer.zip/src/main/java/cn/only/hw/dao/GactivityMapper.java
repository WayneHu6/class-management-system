package cn.only.hw.dao;

import cn.only.hw.entity.Gactivity;
import cn.only.hw.entity.Notice;

import java.util.List;

public interface GactivityMapper {
    int deleteByPrimaryKey(String agid);

    int insert(Gactivity record);

    int insertSelective(Gactivity record);

    Gactivity selectByPrimaryKey(String agid);

    int updateByPrimaryKeySelective(Gactivity record);

    int updateByPrimaryKey(Gactivity record);

    List<Gactivity> selectAll();

    List<Gactivity> selectByGid(String gid);
}