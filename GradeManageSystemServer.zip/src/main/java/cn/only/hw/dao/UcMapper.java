package cn.only.hw.dao;

import cn.only.hw.entity.Uc;

import java.util.List;

public interface UcMapper {
    int deleteByPrimaryKey(String ucid);

    int insert(Uc record);

    int insertSelective(Uc record);

    Uc selectByPrimaryKey(String ucid);

    int updateByPrimaryKeySelective(Uc record);

    int updateByPrimaryKey(Uc record);

    List<Uc> selectByUserid(String userid);

    List<Uc> selectByCid(String cid);
}