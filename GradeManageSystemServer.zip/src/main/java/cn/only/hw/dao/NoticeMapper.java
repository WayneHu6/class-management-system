package cn.only.hw.dao;

import cn.only.hw.entity.Notice;
import cn.only.hw.entity.NoticeWithBLOBs;

import java.util.List;

public interface NoticeMapper {
    int deleteByPrimaryKey(String nid);

    int insert(NoticeWithBLOBs record);

    int insertSelective(NoticeWithBLOBs record);

    NoticeWithBLOBs selectByPrimaryKey(String nid);

    int updateByPrimaryKeySelective(NoticeWithBLOBs record);

    int updateByPrimaryKeyWithBLOBs(NoticeWithBLOBs record);

    int updateByPrimaryKey(Notice record);

    List<Notice> selectAll();
}