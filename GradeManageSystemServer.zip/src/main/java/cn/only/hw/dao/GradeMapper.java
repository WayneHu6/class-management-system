package cn.only.hw.dao;

import cn.only.hw.entity.Grade;

import java.util.List;

public interface GradeMapper {
    int deleteByPrimaryKey(String gid);

    int insert(Grade record);

    int insertSelective(Grade record);

    Grade selectByPrimaryKey(String gid);

    int updateByPrimaryKeySelective(Grade record);

    int updateByPrimaryKey(Grade record);

    List<Grade> selectAll();
}