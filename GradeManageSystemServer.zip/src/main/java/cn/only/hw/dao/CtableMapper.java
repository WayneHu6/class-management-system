package cn.only.hw.dao;

import cn.only.hw.entity.Ctable;
import cn.only.hw.entity.Gactivity;

import java.util.List;

public interface CtableMapper {
    int deleteByPrimaryKey(String ctid);

    int insert(Ctable record);

    int insertSelective(Ctable record);

    Ctable selectByPrimaryKey(String ctid);

    int updateByPrimaryKeySelective(Ctable record);

    int updateByPrimaryKey(Ctable record);

    List<Ctable> selectByGid(String gid);


    List<Ctable> selectByCid(String cid);
}