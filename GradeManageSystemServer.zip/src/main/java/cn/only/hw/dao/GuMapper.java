package cn.only.hw.dao;

import cn.only.hw.entity.Gu;

import java.util.List;

public interface GuMapper {
    int deleteByPrimaryKey(String guid);

    int insert(Gu record);

    int insertSelective(Gu record);

    Gu selectByPrimaryKey(String guid);

    int updateByPrimaryKeySelective(Gu record);

    int updateByPrimaryKey(Gu record);

    List<Gu> selectByUserid(String userid);

    List<Gu> selectByGid(String gid);
}