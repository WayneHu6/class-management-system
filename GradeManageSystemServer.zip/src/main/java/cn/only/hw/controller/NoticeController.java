package cn.only.hw.controller;


import cn.only.hw.entity.Notice;
import cn.only.hw.entity.NoticeWithBLOBs;
import cn.only.hw.entity.Result;
import cn.only.hw.entity.User;
import cn.only.hw.service.NoticeService;
import cn.only.hw.service.UserService;
import cn.only.hw.utils.CreateRandomStr;
import cn.only.hw.utils.MD5Util;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Controller
@RequestMapping(value = "/notice")
public class NoticeController {

    @Resource
    NoticeService noticeService;


    //    获取所有公告
    @ResponseBody
    @RequestMapping(value = "/getAllNotice", method = RequestMethod.POST)
    public Result getAllNotice(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = noticeService.getAllNotice(user);

        return result;
    }

    //    添加公告
    @ResponseBody
    @RequestMapping(value = "/addNotice", method = RequestMethod.POST)
    public Result addNotice(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String title = jsonObject.getString("title");
        String content = jsonObject.getString("content");

        NoticeWithBLOBs notice = new NoticeWithBLOBs();
        notice.setNid(UUID.randomUUID().toString());
        notice.setTitle(title);
        notice.setContent(content);


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = noticeService.addNotice(user,notice);

        return result;
    }



    //    删除公告
    @ResponseBody
    @RequestMapping(value = "/deleteNotice", method = RequestMethod.POST)
    public Result deleteNotice(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String nid = jsonObject.getString("nid");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = noticeService.deleteNotice(user,nid);

        return result;
    }











}
