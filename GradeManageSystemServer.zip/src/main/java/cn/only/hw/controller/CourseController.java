package cn.only.hw.controller;


import cn.only.hw.entity.Result;
import cn.only.hw.entity.User;
import cn.only.hw.service.CourseService;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

@Controller
@RequestMapping(value = "/course")
public class CourseController {

    @Resource
    CourseService courseService;


    //    获取我的课表
    @ResponseBody
    @RequestMapping(value = "/getCourseTableByUserid", method = RequestMethod.POST)
    public Result getCourseTableByUserid(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = courseService.getCourseTableByUserid(user);

        return result;
    }


    //    获取我的成绩
    @ResponseBody
    @RequestMapping(value = "/getMyScore", method = RequestMethod.POST)
    public Result getMyScore(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = courseService.getMyScore(user);

        return result;
    }









}
