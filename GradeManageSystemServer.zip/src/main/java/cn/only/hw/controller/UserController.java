package cn.only.hw.controller;


import cn.only.hw.entity.*;
import cn.only.hw.service.UserService;
import cn.only.hw.utils.CreateRandomStr;
import cn.only.hw.utils.MD5Util;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Controller
@RequestMapping(value = "/user")
public class UserController {

    @Resource
    UserService userService;


    //    登录的方法
    @ResponseBody
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public Result login(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String psd = jsonObject.getString("psd");


        User user = new User();
        user.setUserid(userid);
        user.setPsd(MD5Util.stringToMD5(psd));

        result = userService.login(user);

        return result;
    }







    

    //    登录的方法
    @ResponseBody
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public Result register(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String name = jsonObject.getString("name");
        String psd = jsonObject.getString("psd");
        String rank = jsonObject.getString("rank"); // 账号级别：0超管用户 1辅导员 2任课老师 3班级干部 4普通学生

        User user = new User();
        user.setUserid(CreateRandomStr.createRandomStr1(6));
        user.setName(name);
        user.setPsd(MD5Util.stringToMD5(psd));
        user.setRank(rank);
        user.setState("1");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        user.setRegistertime(simpleDateFormat.format(new Date()));

        result = userService.register(user);

        return result;
    }

    //    修改密码
    @ResponseBody
    @RequestMapping(value = "/changePsd", method = RequestMethod.POST)
    public Result changePsd(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String oldpsd = jsonObject.getString("oldpsd");
        String newpsd = jsonObject.getString("newpsd");




        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.changePsd(user,oldpsd,newpsd);

        return result;
    }

    //    获取自己的信息
    @ResponseBody
    @RequestMapping(value = "/getPersonInfo", method = RequestMethod.POST)
    public Result getPersonInfo(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getPersonInfo(user);

        return result;
    }

    //    更新自己的信息
    @ResponseBody
    @RequestMapping(value = "/updatePersonInfo", method = RequestMethod.POST)
    public Result updatePersonInfo(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        String name = jsonObject.getString("name");
        String sex = jsonObject.getString("sex");
        String tel = jsonObject.getString("tel");
        String email = jsonObject.getString("email");
        String address = jsonObject.getString("address");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.updatePersonInfo(user,name, sex, tel, email, address);

        return result;
    }





    //    获取我的考勤记录
    @ResponseBody
    @RequestMapping(value = "/getWorkCheck", method = RequestMethod.POST)
    public Result getWorkCheck(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getWorkCheck(user);

        return result;
    }


    //    获取所有课程的考勤记录分析
    @ResponseBody
    @RequestMapping(value = "/getWorkCheckAnalyseAll", method = RequestMethod.POST)
    public Result getWorkCheckAnalyseAll(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getWorkCheckAnalyseAll(user);

        return result;
    }


    //    获取我的课程的考勤记录分析
    @ResponseBody
    @RequestMapping(value = "/getWorkCheckAnalyseMy", method = RequestMethod.POST)
    public Result getWorkCheckAnalyseMy(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getWorkCheckAnalyseMy(user);

        return result;
    }





    /**
     *
     *
     *
     * 管理员的方法
     *
     *
     * **/


    //    管理员获取所有用户信息
    @ResponseBody
    @RequestMapping(value = "/getAllUserInfo", method = RequestMethod.POST)
    public Result getAllUserInfo(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getAllUserInfo(user);

        return result;
    }

    //    管理员获取所有课程信息
    @ResponseBody
    @RequestMapping(value = "/getAllCourseInfo", method = RequestMethod.POST)
    public Result getAllCourseInfo(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getAllCourseInfo(user);

        return result;
    }



    // 编辑信息的方法
    @ResponseBody
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public Result edit(@RequestBody JSONObject jsonObject) {

        Result result = new Result();

        String token = jsonObject.getString("token");
        String userid = jsonObject.getString("userid");

        String tablename = jsonObject.getString("tablename"); // 表名
        String valkey = jsonObject.getString("valkey"); // 列名
        String valval = jsonObject.getString("valval"); // 列值
        String wheval = jsonObject.getString("wheval"); // where的条件名
        String inid = jsonObject.getString("inid"); // 条件值


        Map<String,String> map = new HashMap<>();
        map.put("tablename",tablename);
        map.put("inid",inid);
        map.put("valkey",valkey);
        map.put("valval",valval);
        map.put("wheval",wheval);


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.edit(user,map);

        return result;

    }


    //    管理员获取添加用户
    @ResponseBody
    @RequestMapping(value = "/addUser", method = RequestMethod.POST)
    public Result addUser(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String name = jsonObject.getString("name");
        String psd = jsonObject.getString("psd");
        String rank = jsonObject.getString("rank"); // 账号级别：0超管用户 1辅导员 2任课老师 3班级干部 4普通学生



        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        User userIn = new User();
        userIn.setUserid(CreateRandomStr.createRandomStr1(6));
        userIn.setName(name);
        userIn.setPsd(MD5Util.stringToMD5(psd));
        userIn.setRank(rank);
        userIn.setState("1");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        userIn.setRegistertime(simpleDateFormat.format(new Date()));

        result = userService.addUser(user,userIn);

        return result;
    }



    //    管理员删除用户
    @ResponseBody
    @RequestMapping(value = "/deleteUser", method = RequestMethod.POST)
    public Result deleteUser(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String useridIn = jsonObject.getString("useridIn");




        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.deleteUser(user,useridIn);

        return result;
    }










    /**
     *
     *
     *
     * 班干部的方法
     *
     *
     * **/

    // 班干部获取我的班级学生信息
    @ResponseBody
    @RequestMapping(value = "/getStudentByUserid", method = RequestMethod.POST)
    public Result getStudentByUserid(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getStudentByUserid(user);

        return result;
    }



    // 班干部获取我的班级学生的出勤记录
    @ResponseBody
    @RequestMapping(value = "/getWorkCheckByUserid", method = RequestMethod.POST)
    public Result getWorkCheckByUserid(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getWorkCheckByUserid(user);

        return result;
    }
    // 删除考勤记录
    @ResponseBody
    @RequestMapping(value = "/deleteWorkRecord", method = RequestMethod.POST)
    public Result deleteWorkRecord(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");
        String wcid = jsonObject.getString("wcid");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.deleteWorkRecord(user,wcid);
        return result;
    }
    // 添加考勤记录
    @ResponseBody
    @RequestMapping(value = "/addWorkRecord", method = RequestMethod.POST)
    public Result addWorkRecord(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String useridIn = jsonObject.getString("useridIn");
        String cid = jsonObject.getString("cid");
        String state = jsonObject.getString("state");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.addWorkRecord(user,useridIn,cid,state);
        return result;
    }






    // 班干部获取我的班级的开支记录
    @ResponseBody
    @RequestMapping(value = "/getSpendByUserid", method = RequestMethod.POST)
    public Result getSpendByUserid(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getSpendByUserid(user);

        return result;
    }
    // 删除我的班级开支
    @ResponseBody
    @RequestMapping(value = "/deleteSpend", method = RequestMethod.POST)
    public Result deleteSpend(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");
        String sgid = jsonObject.getString("sgid");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.deleteSpend(user,sgid);
        return result;
    }
    // 添加我的班级开支
    @ResponseBody
    @RequestMapping(value = "/addSpend", method = RequestMethod.POST)
    public Result addSpend(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String num = jsonObject.getString("num");
        String content = jsonObject.getString("content");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.addSpend(user,num,content);
        return result;
    }




    // 获取我的班级活动
    @ResponseBody
    @RequestMapping(value = "/getActivityByUserid", method = RequestMethod.POST)
    public Result getActivityByUserid(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getActivityByUserid(user);

        return result;
    }
    // 删除我的班级活动
    @ResponseBody
    @RequestMapping(value = "/deleteActivity", method = RequestMethod.POST)
    public Result deleteActivity(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");
        String agid = jsonObject.getString("agid");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.deleteActivity(user,agid);
        return result;
    }
    // 添加班级活动
    @ResponseBody
    @RequestMapping(value = "/addActivity", method = RequestMethod.POST)
    public Result addActivity(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String title = jsonObject.getString("title");
        String content = jsonObject.getString("content");

        Gactivity gactivity = new Gactivity();
        gactivity.setAgid(UUID.randomUUID().toString());
        gactivity.setTitle(title);
        gactivity.setContent(content);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        gactivity.setSendtime(simpleDateFormat.format(new Date()));

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.addActivity(user,gactivity);
        return result;
    }







    /**
     *
     *
     *
     *
     *
     * 任课教师
     *
     *
     *
     *
     *
     * **/

    // 任课教师获取自己的课程表
    @ResponseBody
    @RequestMapping(value = "/getTeacherCourse", method = RequestMethod.POST)
    public Result getTeacherCourse(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getTeacherCourse(user);
        return result;
    }

    // 任课教师获取自己的学生信息
    @ResponseBody
    @RequestMapping(value = "/getTeacherStudent", method = RequestMethod.POST)
    public Result getTeacherStudent(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getTeacherStudent(user);
        return result;
    }

    // 任课教师获取自己的课程的成绩
    @ResponseBody
    @RequestMapping(value = "/getTeacherScore", method = RequestMethod.POST)
    public Result getTeacherScore(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getTeacherScore(user);
        return result;
    }
    // 任课教师获取自己的课程的考勤
    @ResponseBody
    @RequestMapping(value = "/getTeacherWork", method = RequestMethod.POST)
    public Result getTeacherWork(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getTeacherWork(user);
        return result;
    }





    /**
     *
     *
     *
     * 辅导员
     *
     *
     *
     *
     *
     * ***/

    // 辅导员获取学生信息
    @ResponseBody
    @RequestMapping(value = "/getStudent", method = RequestMethod.POST)
    public Result getStudent(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getStudent(user);
        return result;
    }

    // 辅导员获取老师信息
    @ResponseBody
    @RequestMapping(value = "/getTeacher", method = RequestMethod.POST)
    public Result getTeacher(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getTeacher(user);
        return result;
    }

    // 辅导员获取课程信息
    @ResponseBody
    @RequestMapping(value = "/getCourse", method = RequestMethod.POST)
    public Result getCourse(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getCourse(user);
        return result;
    }

    // 辅导员添加课程信息
    @ResponseBody
    @RequestMapping(value = "/addCourse", method = RequestMethod.POST)
    public Result addCourse(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String cname = jsonObject.getString("cname");
        String useridIn = jsonObject.getString("useridIn");

        Course course = new Course();
        course.setCid(UUID.randomUUID().toString());
        course.setName(cname);
        course.setUserid(useridIn);

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.addCourse(user,course);
        return result;
    }

    // 辅导员删除课程信息
    @ResponseBody
    @RequestMapping(value = "/deleteCourse", method = RequestMethod.POST)
    public Result deleteCourse(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String cid = jsonObject.getString("cid");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.deleteCourse(user,cid);
        return result;
    }




    // 辅导员获取班级信息
    @ResponseBody
    @RequestMapping(value = "/getGrade", method = RequestMethod.POST)
    public Result getGrade(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.getGrade(user);
        return result;
    }
    // 辅导员添加班级
    @ResponseBody
    @RequestMapping(value = "/addGrade", method = RequestMethod.POST)
    public Result addGrade(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String name = jsonObject.getString("name");

        Grade grade = new Grade();
        grade.setGid(UUID.randomUUID().toString());
        grade.setName(name);
        grade.setInstructor(userid);
        grade.setMoney(new BigDecimal(0));


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.addGrade(user,grade);
        return result;
    }
    // 辅导员删除班级信息
    @ResponseBody
    @RequestMapping(value = "/deleteGrade", method = RequestMethod.POST)
    public Result deleteGrade(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String gid = jsonObject.getString("gid");

        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = userService.deleteGrade(user,gid);
        return result;
    }









}
