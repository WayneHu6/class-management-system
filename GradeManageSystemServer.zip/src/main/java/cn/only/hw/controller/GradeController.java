package cn.only.hw.controller;


import cn.only.hw.entity.Result;
import cn.only.hw.entity.User;
import cn.only.hw.service.GradeService;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

@Controller
@RequestMapping(value = "/grade")
public class GradeController {

    @Resource
    GradeService gradeService;


    //    获取所有班级活动
    @ResponseBody
    @RequestMapping(value = "/getAllGA", method = RequestMethod.POST)
    public Result getAllGA(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = gradeService.getAllGA(user);

        return result;
    }



    //    获取自己的班级活动
    @ResponseBody
    @RequestMapping(value = "/getGAByUserid", method = RequestMethod.POST)
    public Result getGAByUserid(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = gradeService.getGAByUserid(user);

        return result;
    }


    //    通过班级ID获取班级公告
    @ResponseBody
    @RequestMapping(value = "/getGAByGid", method = RequestMethod.POST)
    public Result getGAByGid(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String gid = jsonObject.getString("gid");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = gradeService.getGAByGid(user,gid);

        return result;
    }



    //    获取自己的班级开支信息
    @ResponseBody
    @RequestMapping(value = "/getGSByUserid", method = RequestMethod.POST)
    public Result getGSByUserid(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = gradeService.getGSByUserid(user);

        return result;
    }


    //    通过班级ID获取班级开支
    @ResponseBody
    @RequestMapping(value = "/getGSByGid", method = RequestMethod.POST)
    public Result getGSByGid(@RequestBody JSONObject jsonObject) {
        Result result = new Result();

        String userid = jsonObject.getString("userid");
        String token = jsonObject.getString("token");

        String gid = jsonObject.getString("gid");


        User user = new User();
        user.setUserid(userid);
        user.setToken(token);

        result = gradeService.getGSByGid(user,gid);

        return result;
    }











}
