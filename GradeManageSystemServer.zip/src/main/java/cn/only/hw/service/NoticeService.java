package cn.only.hw.service;


import cn.only.hw.entity.NoticeWithBLOBs;
import cn.only.hw.entity.Result;
import cn.only.hw.entity.User;

import java.util.Map;


public interface NoticeService {

    Result getAllNotice(User user);


    Result addNotice(User user, NoticeWithBLOBs notice);

    Result deleteNotice(User user, String nid);
}
