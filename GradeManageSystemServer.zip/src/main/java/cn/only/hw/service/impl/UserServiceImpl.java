package cn.only.hw.service.impl;


import cn.only.hw.dao.*;
import cn.only.hw.entity.*;
import cn.only.hw.service.UserService;
import cn.only.hw.utils.MD5Util;
import com.sun.corba.se.spi.orbutil.threadpool.Work;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private WorkcheckMapper workcheckMapper;
    @Autowired
    private CourseMapper courseMapper;
    @Autowired
    private GuMapper guMapper;
    @Autowired
    private GradeMapper gradeMapper;
    @Autowired
    private GspendMapper gspendMapper;
    @Autowired
    private GactivityMapper gactivityMapper;
    @Autowired
    private CtableMapper ctableMapper;
    @Autowired
    private UcMapper ucMapper;



    @Override
    public Result login(User user) {

        User userDB = userMapper.login(user);
        if (userDB != null) {
            String token = MD5Util.stringToMD5(userDB.getUserid() + userDB.getPsd() + getDatetime());
            userDB.setToken(token);
            userDB.setLastlogintime(getDatetime());
            int stateUpdateToken = userMapper.updateByPrimaryKey(userDB);
            if (stateUpdateToken == 1) {
                return success().add("info", userDB);
            } else {
                return sysError();
            }
        } else {
            return error("账号或密码错误！");
        }
    }

    @Override
    public Result register(User user) {
        if (user.getRank().equals("2") || user.getRank().equals("4")) {
            User userList = userMapper.selectByPrimaryKey(user.getUserid());
            if (userList != null) {
                return error("注册失败--id存在");
            } else {
                int state = userMapper.insert(user);
                if (state == 1) {
                    return success();
                } else {
                    return error("注册失败");
                }
            }
        } else {
            return error("暂时不能注册此权限的账号！");
        }


    }

    @Override
    public Result getPersonInfo(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
                User userDB = userMapper.selectByPrimaryKey(user.getUserid());
                if (userDB != null) {
                    return success().add("info", userDB);
                } else {
                    return error("没有用户信息！");
                }

        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result updatePersonInfo(User user, String name, String sex, String tel, String email, String address) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            userToken.setName(name);
            userToken.setSex(sex);
            userToken.setEmail(email);
            userToken.setTel(tel);
            userToken.setAddress(address);
            int state = userMapper.updateByPrimaryKey(userToken);
            if (state ==  1) {
                return success();
            } else {
                return sysError();
            }

        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getAllUserInfo(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2") || rank.equals("3") || rank.equals("4")) {
                List<User> userList = userMapper.selectAll();
                if (userList.size() > 0) {
                    return success().add("info", userList);
                } else {
                    return error("没有用户信息！");
                }
            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }


    @Override
    public Result getAllCourseInfo(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2") || rank.equals("3") || rank.equals("4")) {
                List<Course> courseList = courseMapper.selectAll();
                if (courseList.size() > 0) {
                    return success().add("info", courseList);
                } else {
                    return error("没有课程信息！");
                }
            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getTeacherCourse(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2")) {
               // 通过userid获取到教师的课程所属id
                List<Course> courseList = courseMapper.selectByUserid(userToken.getUserid());
                if (courseList.size()>0){
                    // 通过课程id获取课程安排
                    List<Ctable> ctableList =  ctableMapper.selectByCid(courseList.get(0).getCid());
                    if (ctableList.size()>0){
                        // 返回课程安排信息
                        JSONArray jsonArray = new JSONArray();
                        if (ctableList.size() > 0) {
                            for (int i = 0; i < ctableList.size(); i++) {
                                // 获取课程名
                                Course course = courseMapper.selectByPrimaryKey(ctableList.get(i).getCid());
                                // 获取任课教师名
                                User userTeacher = userMapper.selectByPrimaryKey(course.getUserid());
                                JSONObject jsonObject = new JSONObject();
                                jsonObject.put("ctable", ctableList.get(i));
                                jsonObject.put("course", course);
                                jsonObject.put("teacher", userTeacher);
                                jsonArray.add(jsonObject);
                            }

                            return success().add("info", jsonArray);
                        }else{
                            return error("没有课表信息！");
                        }

                    }else{
                        return error("暂时没有您的课程安排");
                    }
                }else{
                    return error("暂时没有您的课程安排");
                }


            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getTeacherStudent(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2")) {
                // 通过教师id获取自己所带课程id
                List<Course> courseList = courseMapper.selectByUserid(userToken.getUserid());
                if (courseList.size()>0){
                    List<Uc> ucs = ucMapper.selectByCid(courseList.get(0).getCid());
                    if (ucs.size()>0){
                        // 通过课程id获取课程所属学生
                        List<User> userList = new ArrayList<>();
                        for (int i = 0; i < ucs.size(); i++) {
                            // 通过学生id获取所有学生信息
                            User userDB = userMapper.selectByPrimaryKey(ucs.get(i).getUserid());
                            userList.add(userDB);
                        }
                        return success().add("info",userList);
                    }else{
                        return error("没有课程信息");
                    }
                }else{
                    return error("没有您的课程信息");

                }

            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getTeacherScore(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2")) {
                // 通过教师id获取自己所带课程id
                List<Course> courseList = courseMapper.selectByUserid(userToken.getUserid());
                if (courseList.size()>0){
                    List<Uc> ucs = ucMapper.selectByCid(courseList.get(0).getCid());
                    if (ucs.size()>0){

                        JSONArray jsonArray = new JSONArray();
                        for (int i = 0; i < ucs.size(); i++) {
                            // 获取课程名
                            Course course = courseMapper.selectByPrimaryKey(ucs.get(i).getCid());
                            // 获取任课教师名
                            User userTeacher = userMapper.selectByPrimaryKey(ucs.get(i).getUserid());
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("uc",ucs.get(i));
                            jsonObject.put("course", course);
                            jsonObject.put("teacher", userTeacher);
                            jsonArray.add(jsonObject);
                        }
                        return success().add("info", jsonArray);


                    }else{
                        return error("没有课程信息");
                    }
                }else{
                    return error("没有您的课程信息");

                }

            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }




    @Override
    public Result getTeacherWork(User user) {
        return null;
    }

    @Override
    public Result getStudent(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2")) {
                List<User> userList = userMapper.selectAll();
                List<User> userFinal = new ArrayList<>();
                if (userList.size()>0){
                    for (int i = 0; i < userList.size(); i++) {
                        if (userList.get(i).getRank().equals("4")){
                            userFinal.add(userList.get(i));
                        }
                    }
                    return success().add("info",userFinal);
                }else{
                    return error("暂时没有学生信息");
                }


            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getTeacher(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2")) {
                List<User> userList = userMapper.selectAll();
                List<User> userFinal = new ArrayList<>();
                if (userList.size()>0){
                    for (int i = 0; i < userList.size(); i++) {
                        if (userList.get(i).getRank().equals("2")){
                            userFinal.add(userList.get(i));
                        }
                    }
                    return success().add("info",userFinal);
                }else{
                    return error("暂时没有学生信息");
                }


            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getCourse(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2")) {
                List<Course> courseList = courseMapper.selectAll();
                if (courseList.size()>0){
                    JSONArray jsonArray = new JSONArray();
                    for (int i = 0; i < courseList.size(); i++) {
                        // 通过课程里的userid获取任课教师
                        JSONObject jsonObject = new JSONObject();
                        User userDB = userMapper.selectByPrimaryKey(courseList.get(i).getUserid());
                        jsonObject.put("course",courseList.get(i));
                        jsonObject.put("teacher",userDB);
                        jsonArray.add(jsonObject);
                    }

                    return success().add("info",jsonArray);

                }else{
                    return error("暂时没有课程信息");
                }

            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result addCourse(User user, Course course) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1")) {
               int state = courseMapper.insert(course);
               if (state == 1){
                   return success();
               }else{
                   return sysError();
               }
            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result deleteCourse(User user, String cid) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1")) {
                int state = courseMapper.deleteByPrimaryKey(cid);
                if (state == 1){
                    return success();
                }else{
                    return sysError();
                }
            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getGrade(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1")) {
                List<Grade> gradeList = gradeMapper.selectAll();
                if (gradeList.size()>0){
                    return success().add("info",gradeList);
                }else{
                    return error("暂时没有班级信息");
                }

            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result addGrade(User user, Grade grade) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1")) {
                int state = gradeMapper.insert(grade);
                if (state == 1){
                    return success();
                }else{
                    return sysError();
                }
            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result deleteGrade(User user, String gid) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1")) {
                int state = gradeMapper.deleteByPrimaryKey(gid);
                if (state == 1){
                    return success();
                }else{
                    return sysError();
                }
            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }



    @Override
    public Result edit(User user, Map<String, String> map) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            int state = userMapper.edit(map);
            if (state == 1) {
                return success();
            } else {
                return sysError();
            }
        } else {
            return error("登录状态已过期 请重新登录");
        }
    }

    @Override
    public Result addUser(User user, User userIn) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1")) {
                // 用户信息入库
                User userList = userMapper.selectByPrimaryKey(userIn.getUserid());
                if (userList != null) {
                    return error("添加失败--id存在");
                } else {
                    int state = userMapper.insert(userIn);
                    if (state == 1) {
                        return success();
                    } else {
                        return error("注册失败");
                    }
                }

            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result deleteUser(User user, String useridIn) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1")) {
                // 通过用户id删除用户信息
                int state = userMapper.deleteByPrimaryKey(useridIn);
                if (state == 1) {
                    return success();
                } else {
                    return sysError();
                }

            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result changePsd(User user, String oldpsd, String newpsd) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            // 校验旧密码
            User userOldPsd = new User();
            userOldPsd.setUserid(user.getUserid());
            userOldPsd.setPsd(MD5Util.stringToMD5(oldpsd));
            User userCheckOldPsd = userMapper.login(userOldPsd);
            if (userCheckOldPsd != null) {
                userCheckOldPsd.setPsd(MD5Util.stringToMD5(newpsd));
                int state = userMapper.updateByPrimaryKey(userCheckOldPsd);
                if (state == 1) {
                    return success();
                } else {
                    return sysError();
                }
            } else {
                return error("旧密码错误");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getWorkCheck(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            List<Workcheck> workchecks = workcheckMapper.selectByUserid(user.getUserid());
            JSONArray jsonArray = new JSONArray();

            if (workchecks.size() > 0) {
                for (int i = 0; i < workchecks.size(); i++) {
                    // 获取课程名
                    Course course = courseMapper.selectByPrimaryKey(workchecks.get(i).getCid());
                    // 获取任课教师名
                    User userTeacher = userMapper.selectByPrimaryKey(course.getUserid());
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("workcheck", workchecks.get(i));
                    jsonObject.put("course", course);
                    jsonObject.put("teacher", userTeacher);
                    jsonArray.add(jsonObject);
                }
                return success().add("info", jsonArray);


            } else {
                return error("暂时没有您的考勤记录");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getStudentByUserid(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2") || rank.equals("3")) {
                List<Gu> gus = guMapper.selectByUserid(userToken.getUserid());
                if (gus.size() > 0) {
                    List<Gu> guGrade = guMapper.selectByGid(gus.get(0).getGid());
                    List<User> userList = new ArrayList<>();
                    for (int i = 0; i < guGrade.size(); i++) {
                        User userDB = userMapper.selectByPrimaryKey(guGrade.get(i).getUserid());
                        userList.add(userDB);
                    }
                    if (userList.size() > 0) {
                        return success().add("info", userList);
                    } else {
                        return error("暂未找到您的班级的学生");
                    }
                } else {
                    return error("没有找到您的班级信息");
                }


            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getWorkCheckByUserid(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2") || rank.equals("3")) {

                List<Gu> gus = guMapper.selectByUserid(userToken.getUserid());
                if (gus.size() > 0) {

                    List<Gu> guGrade = guMapper.selectByGid(gus.get(0).getGid());
                    JSONArray jsonArray = new JSONArray();

                    JSONObject jsonObject = null;
                    for (int i = 0; i < guGrade.size(); i++) {

                        User userDB = userMapper.selectByPrimaryKey(guGrade.get(i).getUserid());
                        List<Workcheck> workcheckDB = workcheckMapper.selectByUserid(guGrade.get(i).getUserid());


                        for (int j = 0; j < workcheckDB.size(); j++) {
                            JSONObject jsonObjectWorkFinal = new JSONObject();
                            jsonObjectWorkFinal.put("cid", workcheckDB.get(j).getCid());
                            jsonObjectWorkFinal.put("state", workcheckDB.get(j).getState());
                            jsonObjectWorkFinal.put("time", workcheckDB.get(j).getTime());
                            jsonObjectWorkFinal.put("userid", workcheckDB.get(j).getUserid());
                            jsonObjectWorkFinal.put("wcid", workcheckDB.get(j).getWcid());
                            Course course = courseMapper.selectByPrimaryKey(workcheckDB.get(j).getCid());
                            jsonObjectWorkFinal.put("cname", course.getName());
                            jsonObjectWorkFinal.put("uname", userDB.getName());

                            jsonArray.add(jsonObjectWorkFinal);
                        }

                    }
                    if (jsonArray.size() > 0) {
                        return success().add("info", jsonArray);
                    } else {
                        return error("暂未找到您的班级的学生的考勤记录");
                    }
                } else {
                    return error("没有找到您的班级学生的信息");
                }


            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }


    @Override
        public Result getWorkCheckAnalyseAll(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2") || rank.equals("3")) {
                // 获取所有考勤记录
                List<Workcheck> workcheckList = workcheckMapper.selectAll();
                if (workcheckList.size()>0){
                    JSONArray jsonArray = new JSONArray();

                    JSONArray jsonArray0 = new JSONArray();
                    JSONArray jsonArray1 = new JSONArray();
                    JSONArray jsonArray2 = new JSONArray();

                    for (int i = 0; i < workcheckList.size(); i++) {
                        // 通过考勤记录进行分类
                        JSONObject jsonObject = new JSONObject();


                        if (workcheckList.get(i).getState().equals("0")) {
                            // 缺勤的统计
                            // 通过考勤记录获取课程信息、用户信息
                            User userDB = userMapper.selectByPrimaryKey(workcheckList.get(i).getUserid());
                            Course course = courseMapper.selectByPrimaryKey(workcheckList.get(i).getCid());
                            jsonObject.put("workcheck",workcheckList.get(i));
                            jsonObject.put("user",userDB);
                            jsonObject.put("course",course);
                            jsonArray0.add(jsonObject);
                        }else  if (workcheckList.get(i).getState().equals("1")) {
                            // 出勤的统计
                            // 通过考勤记录获取课程信息、用户信息

                            User userDB = userMapper.selectByPrimaryKey(workcheckList.get(i).getUserid());
                            Course course = courseMapper.selectByPrimaryKey(workcheckList.get(i).getCid());
                            jsonObject.put("workcheck",workcheckList.get(i));
                            jsonObject.put("user",userDB);
                            jsonObject.put("course",course);
                            jsonArray1.add(jsonObject);
                        }else  if (workcheckList.get(i).getState().equals("2")) {
                            // 请假的统计
                            // 通过考勤记录获取课程信息、用户信息
                            User userDB = userMapper.selectByPrimaryKey(workcheckList.get(i).getUserid());
                            Course course = courseMapper.selectByPrimaryKey(workcheckList.get(i).getCid());
                            jsonObject.put("workcheck",workcheckList.get(i));
                            jsonObject.put("user",userDB);
                            jsonObject.put("course",course);
                            jsonArray2.add(jsonObject);

                        }

                    }

                    jsonArray.add(jsonArray0);
                    jsonArray.add(jsonArray1);
                    jsonArray.add(jsonArray2);

                    return success().add("info",jsonArray);
                }else{
                    return error("没有考勤记录");
                }
            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getWorkCheckAnalyseMy(User user) {
        return null;
    }

    @Override
    public Result getSpendByUserid(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2") || rank.equals("3")) {
                List<Gu> gus = guMapper.selectByUserid(userToken.getUserid());
                if (gus.size() > 0) {
                    List<Gspend> gspendDB = gspendMapper.selectByGid(gus.get(0).getGid());
                    if (gspendDB.size() > 0) {
                        return success().add("info", gspendDB);
                    } else {
                        return error("暂未找到您的班级的开支情况");
                    }
                } else {
                    return error("没有找到您的班级信息");
                }


            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getActivityByUserid(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2") || rank.equals("3")) {
                List<Gu> gus = guMapper.selectByUserid(userToken.getUserid());
                if (gus.size() > 0) {
                    List<Gactivity> gactivityList = gactivityMapper.selectByGid(gus.get(0).getGid());
                    if (gactivityList.size() > 0) {
                        return success().add("info", gactivityList);
                    } else {
                        return error("暂未找到您的班级的活动，快去发布一个吧");
                    }
                } else {
                    return error("没有找到您的班级信息");
                }


            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result deleteWorkRecord(User user, String wcid) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2") || rank.equals("3")) {
                int state = workcheckMapper.deleteByPrimaryKey(wcid);
                if (state == 1) {
                    return success();
                } else {
                    return sysError();
                }

            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result deleteSpend(User user, String sgid) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("3")) {
                int state = gspendMapper.deleteByPrimaryKey(sgid);
                ;
                if (state == 1) {
                    return success();
                } else {
                    return sysError();
                }

            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result deleteActivity(User user, String agid) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("3")) {
                int state = gactivityMapper.deleteByPrimaryKey(agid);
                if (state == 1) {
                    return success();
                } else {
                    return sysError();
                }

            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result addActivity(User user, Gactivity gactivity) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("3")) {
                // 获取班级id
                List<Gu> gus = guMapper.selectByUserid(user.getUserid());
                if (gus.size() > 0) {
                    gactivity.setGid(gus.get(0).getGid());
                    int state = gactivityMapper.insert(gactivity);
                    if (state == 1) {
                        return success();
                    } else {
                        return sysError();
                    }
                } else {
                    return error("没有您的班级信息");
                }


            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result addSpend(User user, String num, String content) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("3")) {
                // 获取班级id
                List<Gu> gus = guMapper.selectByUserid(user.getUserid());
                if (gus.size() > 0) {
                    Grade grade = gradeMapper.selectByPrimaryKey(gus.get(0).getGid());
                    BigDecimal bigDecimal = grade.getMoney();
                    if (bigDecimal.compareTo(new BigDecimal(num)) == 1) {
                        BigDecimal bigDecimalFinal = bigDecimal.subtract(new BigDecimal(num));

                        Gspend gspend = new Gspend();
                        gspend.setSgid(UUID.randomUUID().toString());
                        gspend.setGid(gus.get(0).getGid());
                        gspend.setBalance(bigDecimalFinal);
                        gspend.setContent(String.format("支出 ￥%s元 用于 %s 支出后结余：￥%s元---操作人：%s", num, content, bigDecimalFinal.toString(), userToken.getName()));

                        int state = gspendMapper.insert(gspend);
                        if (state == 1) {
                            return success();
                        } else {
                            return sysError();
                        }
                    } else {
                        return error("可用于支配的余额不足！");
                    }


                } else {
                    return error("没有您的班级信息");
                }


            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result addWorkRecord(User user, String useridIn, String cid, String state) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1") || rank.equals("2") || rank.equals("3")) {
                Workcheck workcheck = new Workcheck();
                workcheck.setWcid(UUID.randomUUID().toString());
                workcheck.setCid(cid);
                workcheck.setUserid(useridIn);
                workcheck.setState(state);
                workcheck.setTime(getDatetime());
                int stateDao = workcheckMapper.insert(workcheck);
                if (stateDao == 1) {
                    return success();
                } else {
                    return sysError();
                }

            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }




    /*
     *
     * 错误返回
     *
     * */
    private Result success() {
        /**
         * 作者：户伟伟
         * description: 成功
         * create time: 2022/1/15 19:58
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        return result = result.success();
    }

    private Result error(String info) {
        /**
         * 作者：户伟伟
         * description: 错误
         * create time: 2022/1/15 19:59
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        result = result.fail();
        result.add("info", info);
        return result;
    }

    private Result sysError() {
        /**
         * 作者：户伟伟
         * description: 系统故障
         * create time: 2022/1/15 19:59
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        result = result.fail();
        result.add("info", "系统故障");
        return result;
    }

    /*
     *
     * 获取今天的日期字符串 yyyy-MM-dd HH:mm:ss
     *
     * */
    private String getDatetime() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        return simpleDateFormat.format(date);
    }


}
