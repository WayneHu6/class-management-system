package cn.only.hw.service.impl;


import cn.only.hw.dao.*;
import cn.only.hw.entity.*;
import cn.only.hw.service.CourseService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


@Service
public class CourseServiceImpl implements CourseService {
    @Autowired
    private UserMapper userMapper;

    @Autowired
    private GuMapper guMapper;
    @Autowired
    private CtableMapper ctableMapper;
    @Autowired
    private CourseMapper courseMapper;
    @Autowired
    private UcMapper ucMapper;


    @Override
    public Result getMyScore(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            List<Uc> ucList = ucMapper.selectByUserid(user.getUserid());
            if (ucList.size() > 0) {

                JSONArray jsonArray = new JSONArray();
                for (int i = 0; i < ucList.size(); i++) {
                    // 获取课程名
                    Course course = courseMapper.selectByPrimaryKey(ucList.get(i).getCid());
                    // 获取任课教师名
                    User userTeacher = userMapper.selectByPrimaryKey(course.getUserid());
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("uc",ucList.get(i));
                    jsonObject.put("course", course);
                    jsonObject.put("teacher", userTeacher);
                    jsonArray.add(jsonObject);
                }
                return success().add("info", jsonArray);

            } else {
                return error("没有选课信息");
            }

        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }


    @Override
    public Result getCourseTableByUserid(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            List<Gu> guList = guMapper.selectByUserid(user.getUserid());
            if (guList.size() > 0) {
                List<Ctable> ctableList = ctableMapper.selectByGid(guList.get(0).getGid());
                JSONArray jsonArray = new JSONArray();
                if (ctableList.size() > 0) {
                    for (int i = 0; i < ctableList.size(); i++) {
                        // 获取课程名
                        Course course = courseMapper.selectByPrimaryKey(ctableList.get(i).getCid());
                        // 获取任课教师名
                        User userTeacher = userMapper.selectByPrimaryKey(course.getUserid());
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("ctable", ctableList.get(i));
                        jsonObject.put("course", course);
                        jsonObject.put("teacher", userTeacher);
                        jsonArray.add(jsonObject);
                    }

                    return success().add("info", jsonArray);
                } else {
                    return error("没有课表信息！");
                }
            } else {
                return error("没找到班级信息");
            }

        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }


    /*
     *
     * 错误返回
     *
     * */
    private Result success() {
        /**
         * 作者：户伟伟
         * description: 成功
         * create time: 2022/1/15 19:58
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        return result = result.success();
    }

    private Result error(String info) {
        /**
         * 作者：户伟伟
         * description: 错误
         * create time: 2022/1/15 19:59
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        result = result.fail();
        result.add("info", info);
        return result;
    }

    private Result sysError() {
        /**
         * 作者：户伟伟
         * description: 系统故障
         * create time: 2022/1/15 19:59
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        result = result.fail();
        result.add("info", "系统故障");
        return result;
    }

    /*
     *
     * 获取今天的日期字符串 yyyy-MM-dd HH:mm:ss
     *
     * */
    private String getDatetime() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        return simpleDateFormat.format(date);
    }


}
