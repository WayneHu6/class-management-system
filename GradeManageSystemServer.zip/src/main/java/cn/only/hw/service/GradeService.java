package cn.only.hw.service;


import cn.only.hw.entity.Result;
import cn.only.hw.entity.User;


public interface GradeService {


    Result getAllGA(User user);

    Result getGAByUserid(User user);

    Result getGAByGid(User user, String gid);

    Result getGSByUserid(User user);

    Result getGSByGid(User user, String gid);
}
