package cn.only.hw.service;


import cn.only.hw.entity.*;

import java.util.Map;


public interface UserService {

    Result login(User user);


    Result register(User user);

    Result getAllUserInfo(User user);

    Result edit(User user, Map<String, String> map);

    Result addUser(User user, User userIn);

    Result deleteUser(User user, String useridIn);

    Result changePsd(User user, String oldpsd, String newpsd);

    Result getWorkCheck(User user);

    Result getStudentByUserid(User user);

    Result getWorkCheckByUserid(User user);

    Result getSpendByUserid(User user);

    Result getActivityByUserid(User user);

    Result deleteWorkRecord(User user, String wcid);

    Result deleteSpend(User user, String sgid);

    Result deleteActivity(User user, String agid);

    Result addActivity(User user, Gactivity gactivity);

    Result addSpend(User user, String num, String content);

    Result addWorkRecord(User user, String useridIn, String cid, String state);

    Result getAllCourseInfo(User user);

    Result getTeacherCourse(User user);

    Result getTeacherStudent(User user);

    Result getTeacherScore(User user);

    Result getTeacherWork(User user);

    Result getStudent(User user);

    Result getTeacher(User user);

    Result getCourse(User user);

    Result getGrade(User user);

    Result addCourse(User user, Course course);

    Result deleteCourse(User user, String cid);

    Result addGrade(User user, Grade grade);

    Result deleteGrade(User user, String gid);

    Result getPersonInfo(User user);

    Result updatePersonInfo(User user, String name, String sex, String tel, String email, String address);

    Result getWorkCheckAnalyseAll(User user);

    Result getWorkCheckAnalyseMy(User user);
}
