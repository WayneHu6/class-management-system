package cn.only.hw.service.impl;


import cn.only.hw.dao.*;
import cn.only.hw.entity.*;
import cn.only.hw.service.GradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


@Service
public class GradeServiceImpl implements GradeService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private GactivityMapper gactivityMapper;
    @Autowired
    private GuMapper guMapper;
    @Autowired
    private GradeMapper gradeMapper;
    @Autowired
    private GspendMapper gspendMapper;



    @Override
    public Result getAllGA(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null){
            List<Gactivity> gactivities = gactivityMapper.selectAll();
            if (gactivities.size()>0){
                return success().add("info",gactivities);
            }else{
                return error("没有公告信息！");
            }
        }else{
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getGAByUserid(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null){
            List<Gu> guList = guMapper.selectByUserid(user.getUserid());
            if (guList.size()>0){
                List<Gactivity> gactivities = gactivityMapper.selectByGid(guList.get(0).getGid());
                if (gactivities.size()>0){
                    return success().add("info",gactivities);
                }else{
                    return error("没有班级公告信息！");
                }
            }else{
                return error("没找到班级信息");
            }

        }else{
            return error("登录状态已过期 请重新登陆！");
        }
    }





    @Override
    public Result getGAByGid(User user, String gid) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null){
            List<Gactivity> gactivities = gactivityMapper.selectByGid(gid);
            if (gactivities.size()>0){
                return success().add("info",gactivities);
            }else{
                return error("没有公告信息！");
            }
        }else{
            return error("登录状态已过期 请重新登陆！");
        }
    }



    @Override
    public Result getGSByUserid(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null){
            List<Gu> guList = guMapper.selectByUserid(user.getUserid());
            if (guList.size()>0){
                List<Gspend> gspendList = gspendMapper.selectByGid(guList.get(0).getGid());
                if (gspendList.size()>0){
                    return success().add("info",gspendList);
                }else{
                    return error("没有班级开支信息！");
                }
            }else{
                return error("没找到班级信息");
            }

        }else{
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result getGSByGid(User user, String gid) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null){
            List<Gspend> gspendList = gspendMapper.selectByGid(gid);
            if (gspendList.size()>0){
                return success().add("info",gspendList);
            }else{
                return error("没有班级开支信息！");
            }
        }else{
            return error("登录状态已过期 请重新登陆！");
        }
    }


    /*
     *
     * 错误返回
     *
     * */
    private Result success() {
        /**
         * 作者：户伟伟
         * description: 成功
         * create time: 2022/1/15 19:58
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        return result = result.success();
    }

    private Result error(String info) {
        /**
         * 作者：户伟伟
         * description: 错误
         * create time: 2022/1/15 19:59
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        result = result.fail();
        result.add("info", info);
        return result;
    }

    private Result sysError() {
        /**
         * 作者：户伟伟
         * description: 系统故障
         * create time: 2022/1/15 19:59
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        result = result.fail();
        result.add("info", "系统故障");
        return result;
    }

    /*
     *
     * 获取今天的日期字符串 yyyy-MM-dd HH:mm:ss
     *
     * */
    private String getDatetime() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        return simpleDateFormat.format(date);
    }



}
