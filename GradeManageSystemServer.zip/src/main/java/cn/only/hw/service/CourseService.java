package cn.only.hw.service;


import cn.only.hw.entity.Result;
import cn.only.hw.entity.User;


public interface CourseService {


    Result getCourseTableByUserid(User user);

    Result getMyScore(User user);
}
