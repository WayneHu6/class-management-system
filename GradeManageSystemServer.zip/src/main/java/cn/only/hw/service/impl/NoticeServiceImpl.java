package cn.only.hw.service.impl;


import cn.only.hw.dao.NoticeMapper;
import cn.only.hw.dao.UserMapper;
import cn.only.hw.entity.Notice;
import cn.only.hw.entity.NoticeWithBLOBs;
import cn.only.hw.entity.Result;
import cn.only.hw.entity.User;
import cn.only.hw.service.NoticeService;
import cn.only.hw.service.UserService;
import cn.only.hw.utils.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;


@Service
public class NoticeServiceImpl implements NoticeService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private NoticeMapper noticeMapper;



    @Override
    public Result getAllNotice(User user) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null){
            List<Notice> noticeList = noticeMapper.selectAll();
            if (noticeList.size()>0){
                return success().add("info",noticeList);
            }else{
                return error("没有公告信息！");
            }
        }else{
            return error("登录状态已过期 请重新登陆！");
        }
    }


    @Override
    public Result addNotice(User user, NoticeWithBLOBs notice) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1")) {
                int state = noticeMapper.insert(notice);
                if (state == 1){
                    return success();
                }else{
                    return sysError();
                }
            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    @Override
    public Result deleteNotice(User user, String nid) {
        User userToken = userMapper.checkToken(user);
        if (userToken != null) {
            String rank = userToken.getRank();
            if (rank.equals("0") || rank.equals("1")) {
                int state = noticeMapper.deleteByPrimaryKey(nid);
                if (state == 1){
                    return success();
                }else{
                    return sysError();
                }
            } else {
                return error("您的账号没有此权限！");
            }
        } else {
            return error("登录状态已过期 请重新登陆！");
        }
    }

    /*
     *
     * 错误返回
     *
     * */
    private Result success() {
        /**
         * 作者：户伟伟
         * description: 成功
         * create time: 2022/1/15 19:58
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        return result = result.success();
    }

    private Result error(String info) {
        /**
         * 作者：户伟伟
         * description: 错误
         * create time: 2022/1/15 19:59
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        result = result.fail();
        result.add("info", info);
        return result;
    }

    private Result sysError() {
        /**
         * 作者：户伟伟
         * description: 系统故障
         * create time: 2022/1/15 19:59
         *  * @Param:
         * @return cn.only.hw.entity.Result
         */
        Result result = new Result();
        result = result.fail();
        result.add("info", "系统故障");
        return result;
    }

    /*
     *
     * 获取今天的日期字符串 yyyy-MM-dd HH:mm:ss
     *
     * */
    private String getDatetime() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        return simpleDateFormat.format(date);
    }



}
