var host = "192.168.31.109";
var port = "8080";
var project = "GMSS";
var baseurl = "http://" + host + ":" + port + "/" + project + "/";
