


// 登录
function login() {
	
	if (window.localStorage.getItem("islogin") == "is" &&
		window.localStorage.getItem("userid") != null &&
		window.localStorage.getItem("token") != null
	) {
		if(window.localStorage.getItem("rank") === "0"){
			window.location.replace('./ui/Main_Manager');
		}else if(window.localStorage.getItem("rank") === "1"){
			window.location.replace('./ui/Main_Instructor');
		}else if(window.localStorage.getItem("rank") === "2"){
			window.location.replace('./ui/Main_Teacher');
		}else if(window.localStorage.getItem("rank") === "3"){
			window.location.replace('./ui/Main_StudentManage');
		}else if(window.localStorage.getItem("rank") === "4"){
			window.location.replace('./ui/Main_Student');
		}
	}
	
	var userid = document.getElementById("userid").value;
	var psd = document.getElementById("psd").value;
	
	var datas = {
		"userid":userid,
		"psd":psd
	}
	
	$.ajax({
		url: baseurl + "user/login",
		data: JSON.stringify(datas),
		type: "post",
		dataType: "json",
		headers: {
			'Content-Type': 'application/json;charset=utf-8'
		}, //接口json格式
		success: function(data) {
			if (data.code == "200") {

					window.localStorage.setItem("islogin", "is");
					window.localStorage.setItem("token", data.data.info
						.token);
					window.localStorage.setItem("userid", data.data.info
						.userid);
					window.localStorage.setItem("rank", data.data.info
						.rank);
					window.localStorage.setItem("state", data.data.info
						.state);
					window.localStorage.setItem("lastlogin", data.data.info
						.lastlogin);
						window.localStorage.setItem("name", data.data.info
							.name);
						
						if(window.localStorage.getItem("rank") === "0"){
							window.location.replace('./ui/Main_Manager');
						}else if(window.localStorage.getItem("rank") === "1"){
							window.location.replace('./ui/Main_Instructor');
						}else if(window.localStorage.getItem("rank") === "2"){
							window.location.replace('./ui/Main_Teacher');
						}else if(window.localStorage.getItem("rank") === "3"){
							window.location.replace('./ui/Main_StudentManage');
						}else if(window.localStorage.getItem("rank") === "4"){
							window.location.replace('./ui/Main_Student');
						}
					
					
			} else {
				// layer.alert(data.data.info);
				alert(data.data.info);
			}
		},
		error: function(data) {
			layer.alert(JSON.stringify(data), {
				title: data
			});
		}
	});
	
	
	
	
}








// 注册
function register() {
	layui.use(['form'], function() {
		var form = layui.form,
			layer = layui.layer,
			$ = layui.$;

		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认注册吗???", {
				title: '确认'
			}, function() {




				var datas = {
					"token": window.localStorage.getItem("token"),
					"userid": window.localStorage.getItem("userid"),
					
					"name": data.name,
					"psd": data.psd,
					"rank": data.rank
					
				};

				$.ajax({
					url: baseurl + "user/register",
					data: JSON.stringify(datas),
					type: "post",
					dataType: "json",
					headers: {
						'Content-Type': 'application/json;charset=utf-8'
					}, //接口json格式
					success: function(data) {
						if (data.code == "200") {
							layer.msg('注册成功', function() {
								window.location.replace('./index.html');
							});
						} else {
							layer.alert(data.data.info);
						}
					},
					error: function(data) {
						layer.alert(JSON.stringify(data), {
							title: data
						});
					}
				});




			});

			return false;
		});

	});

}










