// 用户管理
function CourseManage() {

	layui.use(['form', 'table'], function() {
		var $ = layui.jquery,
			form = layui.form,
			table = layui.table;

		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "user/getCourse",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "200") {


					var d = data.data.info;

					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'cid',
									width: 300,
									title: '课程号',
									templet:"<div>{{d.course.cid}}</div>"
								},
								{
									field: 'name',
									width: 500,
									title: '课程名	',
									align: "center",
									edit: 'text',
									templet:"<div>{{d.course.name}}</div>"
								},
								{
									field: 'uname',
									width: 500,
									title: '任课课程',
									align: "center",
									templet:"<div>{{d.teacher.name}}</div>"
								},
								{
									title: '操作',
									minWidth: 300,
									toolbar: '#currentTableBar',
									align: "center"
								}

								
							]
						],
						limits: [10, 15, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});


				} else {
					layer.alert(data.data.info);
				}
			},
			error: function(data) {
				layer.alert(JSON.stringify(data), {
					title: data
				});
			}
		});




		/**
		 * toolbar监听事件
		 */
		table.on('toolbar(currentTableFilter)', function(obj) {
			if (obj.event === 'add') { // 监听添加操作
				var index = layer.open({
					title: '添加',
					type: 2,
					shade: 0.2,
					maxmin: true,
					shadeClose: true,
					area: ['100%', '100%'],
					content: 'add.html',
				});
				$(window).on("resize", function() {
					layer.full(index);
				});
			}

		});


		//监听单元格编辑
		table.on('edit(currentTableFilter)', function(obj) {
			var value = obj.value //得到修改后的值
				,
				data = obj.data //得到所在行所有键值
				,
				field = obj.field; //得到字段

			var datas = {
				"token": window.localStorage.getItem("token"),
				"userid": window.localStorage.getItem("userid"),

				"tablename": "course",
				"valkey": field,
				"valval": value,
				"wheval": "cid",
				"inid": data.course.cid,
			};

			$.ajax({
				url: baseurl + "user/edit",
				data: JSON.stringify(datas),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "200") {
						layer.msg('修改成功', function() {
							// obj.del();
							// layer.close(index);
							layer.refresh();
						});
					} else {
						layer.alert(data.data.info);
					}
				},
				error: function(data) {
					layer.alert(JSON.stringify(data), {
						title: data
					});
				}
			});



		});



		table.on('tool(currentTableFilter)', function(obj) {
			var data = obj.data;
			if (obj.event === 'delete') {
				// 执行删除用户操作
				layer.confirm('真的要删除这个课程信息吗？', function(index) {


					var datas = {
						"token": window.localStorage.getItem("token"),
						"userid": window.localStorage.getItem("userid"),
						"cid": data.course.cid
					};

					$.ajax({
						url: baseurl + "user/deleteCourse",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "200") {
								layer.msg('删除成功', function() {
									obj.del();
									layer.close(index);
								});
							} else {
								layer.alert(data.data.info);
							}
						},
						error: function(data) {
							layer.alert(JSON.stringify(data), {
								title: data
							});
						}
					});

				});
			}



		});




	});
}















// 添加用户
function add() {
	layui.use(['form'], function() {
		var form = layui.form,
			layer = layui.layer,
			$ = layui.$;
			
			
			var datas = {
				"token": window.localStorage.getItem("token"),
				"userid": window.localStorage.getItem("userid")
			};
			// 异步加载用户名
			$.ajax({
				url: baseurl + "user/getTeacher",
				data: JSON.stringify(datas),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "200") {
						var list = data.data.info;
						
						for (var i = 0; i < list.length; i++) {
							var option = document.createElement(
								"option"); // 创建添加option属性
							option.setAttribute("value", list[i].userid); // 给option的value添加值
							option.innerText = list[i].name; // 打印option对应的纯文本 
							uaccount.appendChild(option); //给select添加option子标签
							form.render("select"); // 刷性select，显示出数据
							
						}
							
			
					} else {
						layer.alert(data.data.info);
					}
				},
				error: function(data) {
					layer.alert(JSON.stringify(data), {
						title: data
					});
				}
			});
			
			
			
			

		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认添加此课程信息吗???", {
				title: '确认添加'
			}, function() {




				var datas = {
					"token": window.localStorage.getItem("token"),
					"userid": window.localStorage.getItem("userid"),
					
					"cname": data.name,
					"useridIn": data.uaccount
					
				};

				$.ajax({
					url: baseurl + "user/addCourse",
					data: JSON.stringify(datas),
					type: "post",
					dataType: "json",
					headers: {
						'Content-Type': 'application/json;charset=utf-8'
					}, //接口json格式
					success: function(data) {
						if (data.code == "200") {
							layer.msg('添加成功', function() {
								// 关闭弹出层
								layer.close(index);

								var iframeIndex = parent.layer
									.getFrameIndex(window.name);
								parent.layer.close(iframeIndex);
							});
						} else {
							layer.alert(data.data.info);
						}
					},
					error: function(data) {
						layer.alert(JSON.stringify(data), {
							title: data
						});
					}
				});




			});

			return false;
		});

	});

}
