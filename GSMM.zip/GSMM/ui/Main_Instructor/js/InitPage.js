// 页面初始化
function mIndex() {
	var x = window.localStorage.getItem('islogin');
	var y = window.localStorage.getItem('userid');
	var z = window.localStorage.getItem('token');
	if (x != "is" || y == null || z == null) {
		window.location = "../../";
	}

	layui.use(['jquery', 'layer', 'miniAdmin', 'miniTongji'], function() {
		var $ = layui.jquery,
			layer = layui.layer,
			miniAdmin = layui.miniAdmin,
			miniTongji = layui.miniTongji;

		var options = {
			iniUrl: "./data/minit.json", // 初始化接口
			// clearUrl: "api/clear.json", // 缓存清理接口
			urlHashLocation: true, // 是否打开hash定位
			bgColorDefault: false, // 主题默认配置
			multiModule: true, // 是否开启多模块
			menuChildOpen: false, // 是否默认展开菜单
			loadingTime: 0, // 初始化加载时间
			pageAnim: true, // iframe窗口动画
			maxTabNum: 10, // 最大的tab打开数量
		};
		miniAdmin.render(options);
		$("#tv_muname").text(window.localStorage.getItem("name"));
		$('.login-out').on("click", function() {
			layer.msg('退出登录成功', function() {
				window.localStorage.clear();
				window.location = '../../';
			});
		});
	});
}