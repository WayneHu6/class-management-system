function WorkAnalyse() {

	layui.use(['layer', 'echarts'], function() {
		var $ = layui.jquery,
			layer = layui.layer,
			echarts = layui.echarts;

		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "user/getWorkCheckAnalyseAll",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "200") {


					var d = data.data.info;



					/**
					 * 玫瑰图表
					 */
					var echartsPies = echarts.init(document.getElementById('echarts-pies'),
						'walden');
					var optionPies = {
						title: {
							text: '总出勤情况分析',
							left: 'center'
						},
						tooltip: {
							trigger: 'item',
							formatter: '{a} <br/>{b} : {c} ({d}%)'
						},
						legend: {
							orient: 'vertical',
							left: 'left',
							data: ['缺勤', '出勤', '请假']
						},
						series: [{
							name: '访问来源',
							type: 'pie',
							radius: '55%',
							center: ['50%', '60%'],
							roseType: 'radius',
							data: [{
									value: d[0].length,
									name: '缺勤'
								},
								{
									value: d[1].length,
									name: '出勤'
								},
								{
									value: d[2].length,
									name: '请假'
								}
							],
							emphasis: {
								itemStyle: {
									shadowBlur: 10,
									shadowOffsetX: 0,
									shadowColor: 'rgba(0, 0, 0, 0.5)'
								}
							}
						}]
					};
					echartsPies.setOption(optionPies);



					/**
					 * 柱状图
					 */
					var echartsDataset = echarts.init(document.getElementById('echarts-dataset'),
						'walden');

					var optionDataset = {
						legend: {},
						tooltip: {},
						dataset: {
							dimensions: ['product', '缺勤', '出勤', '请假'],
							source: [{
								product: '总出勤情况分析',
								'缺勤': d[0].length,
								'出勤': d[1].length,
								'请假': d[2].length
							}]
						},
						xAxis: {
							type: 'category'
						},
						yAxis: {},
						// Declare several bar series, each will be mapped
						// to a column of dataset.source by default.
						series: [{
								type: 'bar'
							},
							{
								type: 'bar'
							},
							{
								type: 'bar'
							}
						]
					};

					echartsDataset.setOption(optionDataset);




				} else {
					layer.alert(data.data.info);
				}
			},
			error: function(data) {
				layer.alert(JSON.stringify(data), {
					title: data
				});
			}
		});












		// echarts 窗口缩放自适应
		window.onresize = function() {
			echartsRecords.resize();
		}

	});

}
