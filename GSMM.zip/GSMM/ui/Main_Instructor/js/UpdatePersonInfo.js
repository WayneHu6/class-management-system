//
function UpdatePersonInfo() {
	layui.use(['form'], function() {
		var form = layui.form,
			layer = layui.layer,
			$ = layui.$;
			
			
			var datas = {
				"token": window.localStorage.getItem("token"),
				"userid": window.localStorage.getItem("userid")
			};
			// 异步加载用户信息
			$.ajax({
				url: baseurl + "user/getPersonInfo",
				data: JSON.stringify(datas),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "200") {
						var list = data.data.info;
						
				
						var name = document.getElementById("name").setAttribute("value",list.name);
						var sex = document.getElementById("sex");
						if(list.sex === "男"){
							sex.selectedIndex = 1;
							form.render("select"); // 刷性select，显示出数据
						}else{
							sex.selectedIndex = 2;
							form.render("select"); // 刷性select，显示出数据
						}
						
						var tel = document.getElementById("tel").setAttribute("value",list.tel);
						var email = document.getElementById("email").setAttribute("value",list.email);
						var address = document.getElementById("address").setAttribute("value",list.address);
		
							
			
					} else {
						layer.alert(data.data.info);
					}
				},
				error: function(data) {
					layer.alert(JSON.stringify(data), {
						title: data
					});
				}
			});
			
			
			
			

		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认更新信息吗???", {
				title: '确认'
			}, function() {




				var datas = {
					"token": window.localStorage.getItem("token"),
					"userid": window.localStorage.getItem("userid"),
					
					"name": data.name,
					"sex": data.sex,
					"tel": data.tel,
					"email": data.email,
					"address": data.address
					
				};

				$.ajax({
					url: baseurl + "user/updatePersonInfo",
					data: JSON.stringify(datas),
					type: "post",
					dataType: "json",
					headers: {
						'Content-Type': 'application/json;charset=utf-8'
					}, //接口json格式
					success: function(data) {
						if (data.code == "200") {
							layer.msg('更新成功', function() {
								// 关闭弹出层
								layer.close(index);

								var iframeIndex = parent.layer
									.getFrameIndex(window.name);
								parent.layer.close(iframeIndex);
							});
						} else {
							layer.alert(data.data.info);
						}
					},
					error: function(data) {
						layer.alert(JSON.stringify(data), {
							title: data
						});
					}
				});




			});

			return false;
		});

	});

}
