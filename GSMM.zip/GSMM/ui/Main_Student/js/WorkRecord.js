// 获取出勤记录

function getWorkRecord() {

	layui.use(['form', 'table'], function() {
		var $ = layui.jquery,
			form = layui.form,
			table = layui.table;

		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "user/getWorkCheck",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "200") {


					var d = data.data.info;

					table.render({
						elem: '#currentTableId',
						data: d,
						toolbar: '#toolbarDemo',
						defaultToolbar: ['filter', 'exports', 'print', {
							title: '提示',
							layEvent: 'LAYTABLE_TIPS',
							icon: 'layui-icon-tips'
						}],
						cols: [
							[{
									field: 'cid',
									width: 200,
									title: '课程号',
									align: "center",
									templet: "<div>{{d.workcheck.cid}}<div>"
								},
								{
									field: 'cname',
									width: 200,
									title: '课程名称',
									align: "center",
									templet: "<div>{{d.course.name}}<div>"
								},
								{
									field: 'isWork',
									width: 120,
									title: '状态',
									align: "center",
									templet: function(s) {
										if (s.workcheck.state == "2") {
											return "<span style='color:#00aaff;'>请假</span>"
										} else if (s.workcheck.state == "0") {
											return "<span style='color:#aa0000;'>缺勤</span>"
										} else if (s.workcheck.state == "1"){
											return "<span style='color:#55ff00;'>出勤</span>"
										}
									},
								},
								
								{
									field: 'time',
									width: 300,
									title: '记录时间',
									align: "center",
									templet: "<div>{{d.workcheck.time}}<div>"
								},
								{
									field: 'teacher',
									width: 200,
									title: '任课教师',
									align: "center",
									templet: "<div>{{d.teacher.name}}<div>"
								},
								{
									field: 'temail',
									width: 120,
									title: '老师电话',
									align: "center",
									templet: "<div>{{d.teacher.tel}}<div>"
								},
								


							]
						],
						limits: [10, 15, 20, 25, 50, 100],
						limit: d.length,
						page: true,
						skin: 'line'
					});


				} else {
					layer.alert(data.data.info);
				}
			},
			error: function(data) {
				layer.alert(JSON.stringify(data), {
					title: data
				});
			}
		});






	});
}
