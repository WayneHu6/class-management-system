// 用户管理
function getMyCourseTable() {

	layui.use(['form', 'table'], function() {
		var $ = layui.jquery,
			form = layui.form,
			table = layui.table;
			
			

		var datas = {
			"token": window.localStorage.getItem("token"),
			"userid": window.localStorage.getItem("userid"),
		};

		$.ajax({
			url: baseurl + "course/getCourseTableByUserid",
			data: JSON.stringify(datas),
			type: "post",
			dataType: "json",
			headers: {
				'Content-Type': 'application/json;charset=utf-8'
			}, //接口json格式
			success: function(data) {
				if (data.code == "200") {


					var d = data.data.info;
					
					for (var i = 0; i < d.length; i++) {
						layui.$('#w'+d[i].ctable.week+d[i].ctable.time+'')
						.append("<div>课程名："+d[i].course.name+"</div>"+
						"<div>任课教师："+d[i].teacher.name+"</div>"+
						"<div>上课地点："+d[i].ctable.croom+"</div>");
					}
					
					
					

				} else {
					layer.alert(data.data.info);
				}
			},
			error: function(data) {
				layer.alert(JSON.stringify(data), {
					title: data
				});
			}
		});




		/**
		 * toolbar监听事件
		 */
		table.on('toolbar(currentTableFilter)', function(obj) {
			if (obj.event === 'add') { // 监听添加操作
				var index = layer.open({
					title: '添加用户',
					type: 2,
					shade: 0.2,
					maxmin: true,
					shadeClose: true,
					area: ['100%', '100%'],
					content: 'addUser.html',
				});
				$(window).on("resize", function() {
					layer.full(index);
				});
			}

		});


		//监听单元格编辑
		table.on('edit(currentTableFilter)', function(obj) {
			var value = obj.value //得到修改后的值
				,
				data = obj.data //得到所在行所有键值
				,
				field = obj.field; //得到字段

			var datas = {
				"token": window.localStorage.getItem("token"),
				"userid": window.localStorage.getItem("userid"),

				"tablename": "user",
				"valkey": field,
				"valval": value,
				"wheval": "userid",
				"inid": data.userid,
			};

			$.ajax({
				url: baseurl + "user/edit",
				data: JSON.stringify(datas),
				type: "post",
				dataType: "json",
				headers: {
					'Content-Type': 'application/json;charset=utf-8'
				}, //接口json格式
				success: function(data) {
					if (data.code == "200") {
						layer.msg('修改成功', function() {
							// obj.del();
							// layer.close(index);
							layer.refresh();
						});
					} else {
						layer.alert(data.data.info);
					}
				},
				error: function(data) {
					layer.alert(JSON.stringify(data), {
						title: data
					});
				}
			});



		});



		table.on('tool(currentTableFilter)', function(obj) {
			var data = obj.data;
			if (obj.event === 'delete') {
				// 执行删除用户操作
				layer.confirm('真的要删除这个用户吗？', function(index) {


					var datas = {
						"token": window.localStorage.getItem("token"),
						"userid": window.localStorage.getItem("userid"),
						"useridIn": obj.data.userid
					};

					$.ajax({
						url: baseurl + "user/deleteUser",
						data: JSON.stringify(datas),
						type: "post",
						dataType: "json",
						headers: {
							'Content-Type': 'application/json;charset=utf-8'
						}, //接口json格式
						success: function(data) {
							if (data.code == "200") {
								layer.msg('删除成功', function() {
									obj.del();
									layer.close(index);
								});
							} else {
								layer.alert(data.data.info);
							}
						},
						error: function(data) {
							layer.alert(JSON.stringify(data), {
								title: data
							});
						}
					});

				});
			}



		});




	});
}















// 添加用户
function addUser() {
	layui.use(['form'], function() {
		var form = layui.form,
			layer = layui.layer,
			$ = layui.$;

		//监听提交
		form.on('submit(saveBtn)', function(data) {
			var data = data.field;
			var index = layer.alert("确认添加此用户吗???", {
				title: '确认添加'
			}, function() {




				var datas = {
					"token": window.localStorage.getItem("token"),
					"userid": window.localStorage.getItem("userid"),
					
					"name": data.name,
					"psd": data.psd,
					"rank": data.rank
					
				};

				$.ajax({
					url: baseurl + "user/addUser",
					data: JSON.stringify(datas),
					type: "post",
					dataType: "json",
					headers: {
						'Content-Type': 'application/json;charset=utf-8'
					}, //接口json格式
					success: function(data) {
						if (data.code == "200") {
							layer.msg('添加成功', function() {
								// 关闭弹出层
								layer.close(index);

								var iframeIndex = parent.layer
									.getFrameIndex(window.name);
								parent.layer.close(iframeIndex);
							});
						} else {
							layer.alert(data.data.info);
						}
					},
					error: function(data) {
						layer.alert(JSON.stringify(data), {
							title: data
						});
					}
				});




			});

			return false;
		});

	});

}
